﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LetsTravel
{
    public partial class UserInfo : Form
    {
        public UserInfo()
        {
            InitializeComponent();
        }

        private void Load_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True"))
                {
                    con.Open();

                    // SQL query with a parameterized statement
                    string query = "SELECT * FROM Registration WHERE Username = @Username";

                    using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                    {
                        sda.SelectCommand.Parameters.AddWithValue("@Username", usernametext.Text.Trim());

                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        // Display result in DataGridView
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserDashboard ur = new UserDashboard();
            ur.Show();
        }
    }
}
