﻿namespace LetsTravel
{
    partial class FromTicketadmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FromTicketadmin));
            this.Load = new System.Windows.Forms.Button();
            this.txtTicketPrice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTransportName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxSeat = new System.Windows.Forms.ComboBox();
            this.lblSeat = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxTime = new System.Windows.Forms.ComboBox();
            this.lblTime = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.comboBoxTransport = new System.Windows.Forms.ComboBox();
            this.lblTransport = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBoxTo = new System.Windows.Forms.ComboBox();
            this.comboBoxFrom = new System.Windows.Forms.ComboBox();
            this.buttonSearchtrain = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTo = new System.Windows.Forms.Label();
            this.lblFrom = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Load
            // 
            this.Load.Location = new System.Drawing.Point(625, 324);
            this.Load.Name = "Load";
            this.Load.Size = new System.Drawing.Size(97, 34);
            this.Load.TabIndex = 96;
            this.Load.Text = "Load";
            this.Load.UseVisualStyleBackColor = true;
            this.Load.Click += new System.EventHandler(this.Load_Click);
            // 
            // txtTicketPrice
            // 
            this.txtTicketPrice.Location = new System.Drawing.Point(147, 331);
            this.txtTicketPrice.Name = "txtTicketPrice";
            this.txtTicketPrice.Size = new System.Drawing.Size(227, 22);
            this.txtTicketPrice.TabIndex = 95;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 337);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 16);
            this.label4.TabIndex = 94;
            this.label4.Text = "Ticket Price:";
            // 
            // txtTransportName
            // 
            this.txtTransportName.Location = new System.Drawing.Point(147, 114);
            this.txtTransportName.Name = "txtTransportName";
            this.txtTransportName.Size = new System.Drawing.Size(227, 22);
            this.txtTransportName.TabIndex = 93;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 16);
            this.label3.TabIndex = 92;
            this.label3.Text = "Transport Name:";
            // 
            // comboBoxSeat
            // 
            this.comboBoxSeat.FormattingEnabled = true;
            this.comboBoxSeat.Items.AddRange(new object[] {
            "Select seat",
            "S1",
            "S2",
            "S3"});
            this.comboBoxSeat.Location = new System.Drawing.Point(147, 294);
            this.comboBoxSeat.Name = "comboBoxSeat";
            this.comboBoxSeat.Size = new System.Drawing.Size(227, 24);
            this.comboBoxSeat.TabIndex = 91;
            // 
            // lblSeat
            // 
            this.lblSeat.AutoSize = true;
            this.lblSeat.Location = new System.Drawing.Point(93, 302);
            this.lblSeat.Name = "lblSeat";
            this.lblSeat.Size = new System.Drawing.Size(38, 16);
            this.lblSeat.TabIndex = 90;
            this.lblSeat.Text = "Seat:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold);
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(327, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 37);
            this.label2.TabIndex = 89;
            this.label2.Text = "Ticket";
            // 
            // comboBoxTime
            // 
            this.comboBoxTime.FormattingEnabled = true;
            this.comboBoxTime.Items.AddRange(new object[] {
            "select time",
            "7:00 AM",
            "7:00 PM",
            "10:00 PM"});
            this.comboBoxTime.Location = new System.Drawing.Point(147, 258);
            this.comboBoxTime.Name = "comboBoxTime";
            this.comboBoxTime.Size = new System.Drawing.Size(227, 24);
            this.comboBoxTime.TabIndex = 88;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTime.Location = new System.Drawing.Point(90, 266);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(41, 16);
            this.lblTime.TabIndex = 87;
            this.lblTime.Text = "Time:";
            // 
            // buttonBack
            // 
            this.buttonBack.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonBack.Location = new System.Drawing.Point(48, 401);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(83, 33);
            this.buttonBack.TabIndex = 86;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // comboBoxTransport
            // 
            this.comboBoxTransport.FormattingEnabled = true;
            this.comboBoxTransport.Items.AddRange(new object[] {
            "Select transport",
            "Train",
            "Bus",
            "Plane"});
            this.comboBoxTransport.Location = new System.Drawing.Point(147, 81);
            this.comboBoxTransport.Name = "comboBoxTransport";
            this.comboBoxTransport.Size = new System.Drawing.Size(227, 24);
            this.comboBoxTransport.TabIndex = 85;
            // 
            // lblTransport
            // 
            this.lblTransport.AutoSize = true;
            this.lblTransport.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTransport.Location = new System.Drawing.Point(63, 89);
            this.lblTransport.Name = "lblTransport";
            this.lblTransport.Size = new System.Drawing.Size(68, 16);
            this.lblTransport.TabIndex = 84;
            this.lblTransport.Text = "Transport:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(395, 89);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(382, 229);
            this.dataGridView1.TabIndex = 83;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(88, 273);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 82;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(147, 223);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(227, 22);
            this.dateTimePicker1.TabIndex = 81;
            // 
            // comboBoxTo
            // 
            this.comboBoxTo.FormattingEnabled = true;
            this.comboBoxTo.Items.AddRange(new object[] {
            "Select place",
            "Dhaka",
            "Sylhet",
            "Cox\'s Bazar"});
            this.comboBoxTo.Location = new System.Drawing.Point(147, 185);
            this.comboBoxTo.Name = "comboBoxTo";
            this.comboBoxTo.Size = new System.Drawing.Size(227, 24);
            this.comboBoxTo.TabIndex = 80;
            // 
            // comboBoxFrom
            // 
            this.comboBoxFrom.FormattingEnabled = true;
            this.comboBoxFrom.Items.AddRange(new object[] {
            "Select place",
            "Dhaka",
            "Sylhet",
            "Cox\'s Bazar"});
            this.comboBoxFrom.Location = new System.Drawing.Point(147, 148);
            this.comboBoxFrom.Name = "comboBoxFrom";
            this.comboBoxFrom.Size = new System.Drawing.Size(227, 24);
            this.comboBoxFrom.TabIndex = 79;
            // 
            // buttonSearchtrain
            // 
            this.buttonSearchtrain.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonSearchtrain.Location = new System.Drawing.Point(334, 367);
            this.buttonSearchtrain.Name = "buttonSearchtrain";
            this.buttonSearchtrain.Size = new System.Drawing.Size(150, 37);
            this.buttonSearchtrain.TabIndex = 78;
            this.buttonSearchtrain.Text = "Update";
            this.buttonSearchtrain.UseVisualStyleBackColor = true;
            this.buttonSearchtrain.Click += new System.EventHandler(this.buttonSearchtrain_Click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDate.Location = new System.Drawing.Point(92, 228);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(39, 16);
            this.lblDate.TabIndex = 77;
            this.lblDate.Text = "Date:";
            // 
            // lblTo
            // 
            this.lblTo.AutoSize = true;
            this.lblTo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTo.Location = new System.Drawing.Point(104, 193);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new System.Drawing.Size(27, 16);
            this.lblTo.TabIndex = 76;
            this.lblTo.Text = "To:";
            // 
            // lblFrom
            // 
            this.lblFrom.AutoSize = true;
            this.lblFrom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblFrom.Location = new System.Drawing.Point(90, 156);
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.Size = new System.Drawing.Size(41, 16);
            this.lblFrom.TabIndex = 75;
            this.lblFrom.Text = "From:";
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(484, 324);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(100, 34);
            this.Delete.TabIndex = 97;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LetsTravel.Properties.Resources.IMG_9373;
            this.pictureBox2.Location = new System.Drawing.Point(12, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(76, 58);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 98;
            this.pictureBox2.TabStop = false;
            // 
            // FromTicketadmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Load);
            this.Controls.Add(this.txtTicketPrice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTransportName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBoxSeat);
            this.Controls.Add(this.lblSeat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxTime);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.comboBoxTransport);
            this.Controls.Add(this.lblTransport);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBoxTo);
            this.Controls.Add(this.comboBoxFrom);
            this.Controls.Add(this.buttonSearchtrain);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblTo);
            this.Controls.Add(this.lblFrom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FromTicketadmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ticket Admin";
            //this.Load += new System.EventHandler(this.FromTicketadmin_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Load;
        private System.Windows.Forms.TextBox txtTicketPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTransportName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxSeat;
        private System.Windows.Forms.Label lblSeat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxTime;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.ComboBox comboBoxTransport;
        private System.Windows.Forms.Label lblTransport;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBoxTo;
        private System.Windows.Forms.ComboBox comboBoxFrom;
        private System.Windows.Forms.Button buttonSearchtrain;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.Label lblFrom;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}