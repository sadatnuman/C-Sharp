﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LetsTravel
{
    public partial class FromTicketadmin : Form
    {
        public FromTicketadmin()
        {
            InitializeComponent();
            comboBoxTransport.SelectedIndex = 0;
            txtTransportName.Clear();
            comboBoxFrom.SelectedIndex = 0;
            comboBoxTo.SelectedIndex = 0;
            dateTimePicker1.Value = DateTime.Now;
            comboBoxTime.SelectedIndex = 0;
            comboBoxSeat.SelectedIndex = 0;
            txtTicketPrice.Clear();

        }

        private void Load_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Ticket", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void buttonSearchtrain_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBoxTransport.SelectedIndex > 0)
                {
                    if (comboBoxFrom.SelectedIndex > 0 && comboBoxTo.SelectedIndex > 0)
                    {
                        if (comboBoxFrom.SelectedIndex == comboBoxTo.SelectedIndex)
                        {
                            MessageBox.Show("Please select diffrent places ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            comboBoxFrom.SelectedIndex = 0;
                            comboBoxTo.SelectedIndex = 0;
                        }
                        if (comboBoxTime.SelectedIndex > 0)
                        {

                            if (comboBoxSeat.SelectedIndex > 0)
                            {
                                using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True;Encrypt=False"))
                                {
                                    cn.Open();

                                    // Parameterized Query for Insertion (Prevents SQL Injection)
                                    string query = "INSERT INTO Ticket (Transport,TransportName, Frm, Too, Date, Time, Seat, TicketPrice) VALUES (@Transport,@TransportName, @From, @To, @Date, @Time, @Seat, @TicketPrice)";

                                    using (SqlCommand cmd = new SqlCommand(query, cn))
                                    {
                                        // Adding parameters to prevent SQL injection
                                        cmd.Parameters.AddWithValue("@Transport", comboBoxTransport.Text);
                                        cmd.Parameters.AddWithValue("@TransportName", txtTransportName.Text);
                                        cmd.Parameters.AddWithValue("@From", comboBoxFrom.Text);
                                        cmd.Parameters.AddWithValue("@To", comboBoxTo.Text);
                                        cmd.Parameters.AddWithValue("@Date", dateTimePicker1.Value.Date); // Ensures only Date part
                                        cmd.Parameters.AddWithValue("@Time", comboBoxTime.Text);
                                        cmd.Parameters.AddWithValue("@Seat", comboBoxSeat.Text);
                                        cmd.Parameters.AddWithValue("@TicketPrice", Convert.ToInt64(txtTicketPrice.Text));

                                        // Execute the query
                                        int rowsAffected = cmd.ExecuteNonQuery();

                                        // Optional: Provide feedback to the user
                                        if (rowsAffected > 0)
                                        {
                                            MessageBox.Show("Ticket inserted successfully!");
                                        }
                                        else
                                        {
                                            MessageBox.Show("Failed to insert ticket.");
                                        }
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please select any seat", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select any time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select From place and To place", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please select any transport", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDashboard ad = new AdminDashboard();
            ad.Show();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBoxTransport.SelectedIndex > 0)
                {
                    if (comboBoxFrom.SelectedIndex > 0 && comboBoxTo.SelectedIndex > 0)
                    {
                        if (comboBoxFrom.SelectedIndex == comboBoxTo.SelectedIndex)
                        {
                            MessageBox.Show("Please select different places ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            comboBoxFrom.SelectedIndex = 0;
                            comboBoxTo.SelectedIndex = 0;
                        }
                        if (comboBoxTime.SelectedIndex > 0)
                        {
                            if (comboBoxSeat.SelectedIndex > 0)
                            {
                                using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True;Encrypt=False"))
                                {
                                    cn.Open();

                                    // Parameterized Query for Deletion (Prevents SQL Injection)
                                    string query = "DELETE FROM Ticket WHERE Transport = @Transport AND TransportName = @TransportName AND Frm = @From AND Too = @To AND Date = @Date AND Time = @Time AND Seat = @Seat AND TicketPrice = @TicketPrice";

                                    using (SqlCommand cmd = new SqlCommand(query, cn))
                                    {
                                        // Adding parameters to prevent SQL injection
                                        cmd.Parameters.AddWithValue("@Transport", comboBoxTransport.Text);
                                        cmd.Parameters.AddWithValue("@TransportName", txtTransportName.Text);
                                        cmd.Parameters.AddWithValue("@From", comboBoxFrom.Text);
                                        cmd.Parameters.AddWithValue("@To", comboBoxTo.Text);
                                        cmd.Parameters.AddWithValue("@Date", dateTimePicker1.Value.Date); // Ensures only Date part
                                        cmd.Parameters.AddWithValue("@Time", comboBoxTime.Text);
                                        cmd.Parameters.AddWithValue("@Seat", comboBoxSeat.Text);
                                        cmd.Parameters.AddWithValue("@TicketPrice", Convert.ToInt64(txtTicketPrice.Text));

                                        // Execute the query //liy
                                        int rowsAffected = cmd.ExecuteNonQuery();

                                        // Optional: Provide feedback to the user
                                        if (rowsAffected > 0)
                                        {
                                            MessageBox.Show("Ticket deleted successfully!");
                                        }
                                        else
                                        {
                                            MessageBox.Show("No matching ticket found to delete.");
                                        }
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Please select any seat", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select any time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select From place and To place", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please select any transport", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void FromTicketadmin_Load(object sender, EventArgs e)
        {

        }

        private void FromTicketadmin_Load_1(object sender, EventArgs e)
        {

        }
    }
}
