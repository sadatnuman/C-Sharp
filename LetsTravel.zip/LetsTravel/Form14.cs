﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Forms.VisualStyles;

namespace LetsTravel
{
    public partial class UpdateHotelByAdmin : Form
    {
        public UpdateHotelByAdmin()
        {
            InitializeComponent();
            selectcitycmb.SelectedIndex = 0;
            selecthotelcmb.SelectedIndex = 0;
            totalpersoncmb.SelectedIndex = 0;
            numberofdayscmb.SelectedIndex = 0;
            c_in_dtp.Value = DateTime.Now;
            c_out_dtp.Value = DateTime.Now;
        }

        private void UpdateHotelByAdmin_Load(object sender, EventArgs e)
        {

        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDashboard a = new AdminDashboard();
            a.Show();
        }

        private void UpdateHotelByAdmin_Load_1(object sender, EventArgs e)
        {
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            selectcitycmb.SelectedIndex = 0;
            selecthotelcmb.SelectedIndex = 0;
            totalpersoncmb.SelectedIndex = 0;
            numberofdayscmb.SelectedIndex = 0;
            c_in_dtp.Value = DateTime.Now;
            c_out_dtp.Value = DateTime.Now;
        }

        private void Load_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Hotel", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True;Encrypt=False"))
            {
                cn.Open();

                // Parameterized Query for Insertion (Prevents SQL Injection)
                string query = "INSERT INTO Hotel (CityName, HotelName, TotalPerson, NumberOfDays, CheckIn, CheckOut, Price) VALUES (@CityName, @HotelName, @TotalPerson, @NumberOfDays, @CheckIn, @CheckOut, @Price)";

                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    // Adding parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@CityName", selectcitycmb.Text);
                    cmd.Parameters.AddWithValue("@HotelName", selecthotelcmb.Text);
                    cmd.Parameters.AddWithValue("@TotalPerson", Convert.ToInt64(totalpersoncmb.Text));
                    cmd.Parameters.AddWithValue("@NumberOfDays", Convert.ToInt64(numberofdayscmb.Text));
                    cmd.Parameters.AddWithValue("@CheckIn", c_in_dtp.Value.Date);
                    cmd.Parameters.AddWithValue("@CheckOut", c_out_dtp.Value.Date); 
                    cmd.Parameters.AddWithValue("@Price", Convert.ToInt64(textBoxPrice.Text));

                    // Execute the query
                    int rowsAffected = cmd.ExecuteNonQuery();

                    // Optional: Provide feedback to the user
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Hotel info insert successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert hotel info.");
                    }
                }
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True;Encrypt=False"))
            {
                cn.Open();

                // Parameterized Query for Deletion (Prevents SQL Injection)
                string query = "DELETE FROM Hotel WHERE CityName = @CityName AND HotelName = @HotelName AND TotalPerson = @TotalPerson AND NumberOfDays = @NumberOfDays AND CheckIn = @CheckIn AND CheckOut = @CheckOut AND Price = @Price";

                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    // Adding parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@CityName", selectcitycmb.Text);
                    cmd.Parameters.AddWithValue("@HotelName", selecthotelcmb.Text);
                    cmd.Parameters.AddWithValue("@TotalPerson", Convert.ToInt64(totalpersoncmb.Text));
                    cmd.Parameters.AddWithValue("@NumberOfDays", Convert.ToInt64(numberofdayscmb.Text));
                    cmd.Parameters.AddWithValue("@CheckIn", c_in_dtp.Value.Date);
                    cmd.Parameters.AddWithValue("@CheckOut", c_out_dtp.Value.Date);
                    cmd.Parameters.AddWithValue("@Price", Convert.ToInt64(textBoxPrice.Text));

                    // Execute the query
                    int rowsAffected = cmd.ExecuteNonQuery();

                    // Optional: Provide feedback to the user
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Hotel info deleted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("No matching hotel info found to delete.");
                    }
                }
            }

        }
    }
}
