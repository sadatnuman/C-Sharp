﻿namespace LetsTravel
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.PymentDetails = new System.Windows.Forms.Button();
            this.UpdateResort = new System.Windows.Forms.Button();
            this.UpdateResturent = new System.Windows.Forms.Button();
            this.UpdateHotel = new System.Windows.Forms.Button();
            this.UpdateTicket = new System.Windows.Forms.Button();
            this.UpdatePackage = new System.Windows.Forms.Button();
            this.AddUser = new System.Windows.Forms.Button();
            this.UpdateUserInfo = new System.Windows.Forms.Button();
            this.DeleteUser = new System.Windows.Forms.Button();
            this.AddAdmin = new System.Windows.Forms.Button();
            this.UpdateAdminInfo = new System.Windows.Forms.Button();
            this.DeleteAdmin = new System.Windows.Forms.Button();
            this.LogOut = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.Load = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.PymentDetails);
            this.panel1.Controls.Add(this.UpdateResort);
            this.panel1.Controls.Add(this.UpdateResturent);
            this.panel1.Controls.Add(this.UpdateHotel);
            this.panel1.Controls.Add(this.UpdateTicket);
            this.panel1.Controls.Add(this.UpdatePackage);
            this.panel1.Location = new System.Drawing.Point(71, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(803, 91);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // PymentDetails
            // 
            this.PymentDetails.Location = new System.Drawing.Point(681, 23);
            this.PymentDetails.Name = "PymentDetails";
            this.PymentDetails.Size = new System.Drawing.Size(122, 41);
            this.PymentDetails.TabIndex = 7;
            this.PymentDetails.Text = "Payment Details";
            this.PymentDetails.UseVisualStyleBackColor = true;
            this.PymentDetails.Click += new System.EventHandler(this.PymentDetails_Click);
            // 
            // UpdateResort
            // 
            this.UpdateResort.Location = new System.Drawing.Point(382, 23);
            this.UpdateResort.Name = "UpdateResort";
            this.UpdateResort.Size = new System.Drawing.Size(138, 39);
            this.UpdateResort.TabIndex = 6;
            this.UpdateResort.Text = "Update Resort";
            this.UpdateResort.UseVisualStyleBackColor = true;
            this.UpdateResort.Click += new System.EventHandler(this.UpdateResort_Click);
            // 
            // UpdateResturent
            // 
            this.UpdateResturent.Location = new System.Drawing.Point(526, 23);
            this.UpdateResturent.Name = "UpdateResturent";
            this.UpdateResturent.Size = new System.Drawing.Size(153, 41);
            this.UpdateResturent.TabIndex = 5;
            this.UpdateResturent.Text = "Update Resturent";
            this.UpdateResturent.UseVisualStyleBackColor = true;
            this.UpdateResturent.Click += new System.EventHandler(this.button4_Click);
            // 
            // UpdateHotel
            // 
            this.UpdateHotel.Location = new System.Drawing.Point(257, 21);
            this.UpdateHotel.Name = "UpdateHotel";
            this.UpdateHotel.Size = new System.Drawing.Size(119, 39);
            this.UpdateHotel.TabIndex = 4;
            this.UpdateHotel.Text = "Update Hotel";
            this.UpdateHotel.UseVisualStyleBackColor = true;
            this.UpdateHotel.Click += new System.EventHandler(this.UpdateHotel_Click);
            // 
            // UpdateTicket
            // 
            this.UpdateTicket.Location = new System.Drawing.Point(136, 21);
            this.UpdateTicket.Name = "UpdateTicket";
            this.UpdateTicket.Size = new System.Drawing.Size(115, 42);
            this.UpdateTicket.TabIndex = 3;
            this.UpdateTicket.Text = "Update Ticket";
            this.UpdateTicket.UseVisualStyleBackColor = true;
            this.UpdateTicket.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // UpdatePackage
            // 
            this.UpdatePackage.Location = new System.Drawing.Point(3, 23);
            this.UpdatePackage.Name = "UpdatePackage";
            this.UpdatePackage.Size = new System.Drawing.Size(127, 42);
            this.UpdatePackage.TabIndex = 2;
            this.UpdatePackage.Text = "Update Package";
            this.UpdatePackage.UseVisualStyleBackColor = true;
            // 
            // AddUser
            // 
            this.AddUser.Location = new System.Drawing.Point(12, 111);
            this.AddUser.Name = "AddUser";
            this.AddUser.Size = new System.Drawing.Size(123, 28);
            this.AddUser.TabIndex = 1;
            this.AddUser.Text = "Add User";
            this.AddUser.UseVisualStyleBackColor = true;
            this.AddUser.Click += new System.EventHandler(this.AddUser_Click);
            // 
            // UpdateUserInfo
            // 
            this.UpdateUserInfo.Location = new System.Drawing.Point(12, 162);
            this.UpdateUserInfo.Name = "UpdateUserInfo";
            this.UpdateUserInfo.Size = new System.Drawing.Size(123, 51);
            this.UpdateUserInfo.TabIndex = 2;
            this.UpdateUserInfo.Text = "Update User Info";
            this.UpdateUserInfo.UseVisualStyleBackColor = true;
            this.UpdateUserInfo.Click += new System.EventHandler(this.UpdateUserInfo_Click);
            // 
            // DeleteUser
            // 
            this.DeleteUser.Location = new System.Drawing.Point(12, 219);
            this.DeleteUser.Name = "DeleteUser";
            this.DeleteUser.Size = new System.Drawing.Size(123, 36);
            this.DeleteUser.TabIndex = 3;
            this.DeleteUser.Text = "Delete User";
            this.DeleteUser.UseVisualStyleBackColor = true;
            this.DeleteUser.Click += new System.EventHandler(this.DeleteUser_Click);
            // 
            // AddAdmin
            // 
            this.AddAdmin.Location = new System.Drawing.Point(12, 276);
            this.AddAdmin.Name = "AddAdmin";
            this.AddAdmin.Size = new System.Drawing.Size(123, 41);
            this.AddAdmin.TabIndex = 4;
            this.AddAdmin.Text = "Add Admin";
            this.AddAdmin.UseVisualStyleBackColor = true;
            this.AddAdmin.Click += new System.EventHandler(this.AddAdmin_Click);
            // 
            // UpdateAdminInfo
            // 
            this.UpdateAdminInfo.Location = new System.Drawing.Point(12, 336);
            this.UpdateAdminInfo.Name = "UpdateAdminInfo";
            this.UpdateAdminInfo.Size = new System.Drawing.Size(123, 46);
            this.UpdateAdminInfo.TabIndex = 5;
            this.UpdateAdminInfo.Text = "Update Admin Info";
            this.UpdateAdminInfo.UseVisualStyleBackColor = true;
            this.UpdateAdminInfo.Click += new System.EventHandler(this.UpdateAdminInfo_Click);
            // 
            // DeleteAdmin
            // 
            this.DeleteAdmin.Location = new System.Drawing.Point(12, 401);
            this.DeleteAdmin.Name = "DeleteAdmin";
            this.DeleteAdmin.Size = new System.Drawing.Size(123, 37);
            this.DeleteAdmin.TabIndex = 6;
            this.DeleteAdmin.Text = "Delete Admin";
            this.DeleteAdmin.UseVisualStyleBackColor = true;
            this.DeleteAdmin.Click += new System.EventHandler(this.DeleteAdmin_Click);
            // 
            // LogOut
            // 
            this.LogOut.Location = new System.Drawing.Point(579, 402);
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(75, 36);
            this.LogOut.TabIndex = 8;
            this.LogOut.Text = "Log Out";
            this.LogOut.UseVisualStyleBackColor = true;
            this.LogOut.Click += new System.EventHandler(this.LogOut_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(185, 162);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(594, 220);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(387, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 37);
            this.label1.TabIndex = 10;
            this.label1.Text = "Admin Info";
            // 
            // Load
            // 
            this.Load.Location = new System.Drawing.Point(394, 402);
            this.Load.Name = "Load";
            this.Load.Size = new System.Drawing.Size(75, 36);
            this.Load.TabIndex = 11;
            this.Load.Text = "Load";
            this.Load.UseVisualStyleBackColor = true;
            this.Load.Click += new System.EventHandler(this.Load_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(771, 401);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 37);
            this.Exit.TabIndex = 12;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(223, 402);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(99, 36);
            this.Back.TabIndex = 13;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LetsTravel.Properties.Resources.IMG_9373;
            this.pictureBox2.Location = new System.Drawing.Point(12, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(875, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Load);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.LogOut);
            this.Controls.Add(this.DeleteAdmin);
            this.Controls.Add(this.UpdateAdminInfo);
            this.Controls.Add(this.AddAdmin);
            this.Controls.Add(this.DeleteUser);
            this.Controls.Add(this.UpdateUserInfo);
            this.Controls.Add(this.AddUser);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Admin DashBoard";
            //this.Load += new System.EventHandler(this.AdminDashboard_Load_2);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button UpdatePackage;
        private System.Windows.Forms.Button UpdateTicket;
        private System.Windows.Forms.Button UpdateResort;
        private System.Windows.Forms.Button UpdateResturent;
        private System.Windows.Forms.Button UpdateHotel;
        private System.Windows.Forms.Button AddUser;
        private System.Windows.Forms.Button UpdateUserInfo;
        private System.Windows.Forms.Button DeleteUser;
        private System.Windows.Forms.Button AddAdmin;
        private System.Windows.Forms.Button UpdateAdminInfo;
        private System.Windows.Forms.Button DeleteAdmin;
        private System.Windows.Forms.Button LogOut;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button PymentDetails;
        private System.Windows.Forms.Button Load;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}