﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LetsTravel
{
    public partial class ResortUser : Form
    {
        public ResortUser()
        {
            InitializeComponent();
            selectcitycmb.SelectedIndex = 0;
            selectresortcmb.SelectedIndex = 0;
            totalpersoncmb.SelectedIndex = 0;
            numberofdayscmb.SelectedIndex = 0;
            c_in_dtp.Value = DateTime.Now;
            c_out_dtp.Value = DateTime.Now;
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserDashboard a = new UserDashboard();
            a.Show();
        }

        private void Search_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True"))
            {
                cn.Open();

                // Parameterized Query (Prevents SQL Injection)
                string query = "SELECT * FROM Resort WHERE CityName = @CityName AND ResortName = @ResortName AND TotalPerson = @TotalPerson AND NumberOfDays = @NumberOfDays AND CheckIn = @CheckIn AND CheckOut = @CheckOut";

                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    cmd.Parameters.AddWithValue("@CityName", selectcitycmb.Text);
                    cmd.Parameters.AddWithValue("@ResortName", selectresortcmb.Text);
                    cmd.Parameters.AddWithValue("@TotalPerson", Convert.ToInt64(totalpersoncmb.Text));
                    cmd.Parameters.AddWithValue("@NumberOfDays", Convert.ToInt64(numberofdayscmb.Text));
                    cmd.Parameters.AddWithValue("@CheckIn", c_in_dtp.Value.Date);
                    cmd.Parameters.AddWithValue("@CheckOut", c_out_dtp.Value.Date);

                    // Using SqlDataAdapter to fill the DataTable
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    // Binding the result to DataGridView
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            selectcitycmb.SelectedIndex = 0;
            selectresortcmb.SelectedIndex = 0;
            totalpersoncmb.SelectedIndex = 0;
            numberofdayscmb.SelectedIndex = 0;
            c_in_dtp.Value = DateTime.Now;
            c_out_dtp.Value = DateTime.Now;
        }

        private void Payment_Click(object sender, EventArgs e)
        {
            this.Hide();
            Payment p = new Payment();
            p.Show();
        }
    }
}
