﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LetsTravel
{
    public partial class AddAdmin : Form
    {
        DBCoonect dbcon = new DBCoonect();
        public AddAdmin()
        {
            InitializeComponent();
        }

        private void Load_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Admin", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Clear_Click(object sender, EventArgs e)
        {

            // Clearing text fields
            nametext.Clear();
            usernametext.Clear();
            passwordtext.Clear();
            emailtext.Clear();
            phonetext.Clear();

            // Resetting DateTimePicker to today's date
            dob.Value = DateTime.Today;
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDashboard ad = new AdminDashboard();
            ad.Show();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(nametext.Text))
                {
                    MessageBox.Show("Please enter Name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    nametext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(usernametext.Text))
                {
                    MessageBox.Show("Please enter User Name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    usernametext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(passwordtext.Text))
                {
                    MessageBox.Show("Please enter Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    passwordtext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(emailtext.Text))
                {
                    MessageBox.Show("Please enter Email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    emailtext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(phonetext.Text) || !long.TryParse(phonetext.Text, out _))
                {
                    MessageBox.Show("Please enter a valid Phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    phonetext.Focus();
                    return;
                }
                else
                {

                    dbcon.OpenCon();
                    string query = "INSERT INTO Admin (Name, UserName, Password, Email, Phone, DOB) " +
                                   "VALUES (@Name, @UserName, @Password, @Email, @Phone, @DOB)";
                    SqlCommand cmd = new SqlCommand(query, dbcon.GetCon());
                    cmd.Parameters.AddWithValue("@Name", nametext.Text);
                    cmd.Parameters.AddWithValue("@UserName", usernametext.Text);
                    cmd.Parameters.AddWithValue("@Password", passwordtext.Text);
                    cmd.Parameters.AddWithValue("@Email", emailtext.Text);
                    cmd.Parameters.AddWithValue("@Phone", Convert.ToInt64(phonetext.Text));
                    cmd.Parameters.AddWithValue("@DOB", dob.Value);
                    cmd.ExecuteNonQuery();
                    dbcon.CloseCon();

                    MessageBox.Show("Add Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
