﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LetsTravel
{
    public partial class UpdateUserByAdmin : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True");
        public UpdateUserByAdmin()
        {
            InitializeComponent();
        }

        private void Load_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Registration", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDashboard ad = new AdminDashboard();
            ad.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Assigning string values to string-based TextBoxes
                nametext.Text = row.Cells[0].Value.ToString();
                usernametext.Text = row.Cells[1].Value.ToString();
                passwordtext.Text = row.Cells[2].Value.ToString();
                emailtext.Text = row.Cells[3].Value.ToString();

                // Converting integer to string for phone number
                phonetext.Text = row.Cells[4].Value != null ? row.Cells[4].Value.ToString() : "";

                // Handling DateTime for DateTimePicker
                if (row.Cells[5].Value != null && DateTime.TryParse(row.Cells[5].Value.ToString(), out DateTime dobValue))
                {
                    dob.Value = dobValue;
                }
                else
                {
                    dob.Value = DateTime.Today; // Default to today if invalid or null
                }
            }
        }

        private void passwordtext_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateUserByAdmin_Load(object sender, EventArgs e)
        {

        }

        private void Update_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Update Registration set Name = @Name, Password = @Password, Email = @Email , Phone = @Phone , DOB = @DOB where Username=@Username", con);
            cmd.Parameters.AddWithValue("@Name", nametext.Text);
            cmd.Parameters.AddWithValue("@UserName", usernametext.Text);
            cmd.Parameters.AddWithValue("@Password", passwordtext.Text);
            cmd.Parameters.AddWithValue("@Email", emailtext.Text);
            cmd.Parameters.AddWithValue("@Phone", Convert.ToInt64(phonetext.Text));
            cmd.Parameters.AddWithValue("@DOB", dob.Value);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Update Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void Clear_Click(object sender, EventArgs e)
        {
            // Clearing text fields
            nametext.Clear();
            usernametext.Clear();
            passwordtext.Clear();
            emailtext.Clear();
            phonetext.Clear();

            // Resetting DateTimePicker to today's date
            dob.Value = DateTime.Today;
        }
    }
}
