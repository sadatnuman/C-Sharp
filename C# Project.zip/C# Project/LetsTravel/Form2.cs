﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LetsTravel
{
    public partial class Registration : Form
    {
        DBCoonect dbcon = new DBCoonect();
        public Registration()
        {
            InitializeComponent();
        }

        private void registerbutton_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(nametext.Text))
                {
                    MessageBox.Show("Please enter Name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    nametext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(usernametext.Text))
                {
                    MessageBox.Show("Please enter User Name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    usernametext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(passwordtext.Text))
                {
                    MessageBox.Show("Please enter Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    passwordtext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(emailtext.Text))
                {
                    MessageBox.Show("Please enter Email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    emailtext.Focus();
                    return;
                }
                else if (string.IsNullOrWhiteSpace(phonetext.Text) || !long.TryParse(phonetext.Text, out _))
                {
                    MessageBox.Show("Please enter a valid Phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    phonetext.Focus();
                    return;
                }
                else if (dob.Value > DateTime.Now)
                {
                    MessageBox.Show("Invalid Date of Birth.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    dob.Focus();
                    return;
                }
                else
                {

                    dbcon.OpenCon();
                    string query = "INSERT INTO Registration (Name, UserName, Password, Email, Phone, DOB) " +
                                   "VALUES (@Name, @UserName, @Password, @Email, @Phone, @DOB)";
                    SqlCommand cmd = new SqlCommand(query, dbcon.GetCon());
                    cmd.Parameters.AddWithValue("@Name", nametext.Text);
                    cmd.Parameters.AddWithValue("@UserName", usernametext.Text);
                    cmd.Parameters.AddWithValue("@Password", passwordtext.Text);
                    cmd.Parameters.AddWithValue("@Email", emailtext.Text);
                    cmd.Parameters.AddWithValue("@Phone", Convert.ToInt64(phonetext.Text));
                    cmd.Parameters.AddWithValue("@DOB", dob.Value);
                    cmd.ExecuteNonQuery();
                    dbcon.CloseCon();

                    MessageBox.Show("Registration Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Login login = new Login();
                    login.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Registration_Load(object sender, EventArgs e)
        {

        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login l = new Login();
            l.Show();
        }
    }
}
