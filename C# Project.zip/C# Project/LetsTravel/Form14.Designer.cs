﻿namespace LetsTravel
{
    partial class UpdateHotelByAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateHotelByAdmin));
            this.c_out_dtp = new System.Windows.Forms.DateTimePicker();
            this.delete = new System.Windows.Forms.Button();
            this.Load = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Update = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.selectcitylbl = new System.Windows.Forms.Label();
            this.selecthotellbl = new System.Windows.Forms.Label();
            this.totalpersonlbl = new System.Windows.Forms.Label();
            this.numberofdayslbl = new System.Windows.Forms.Label();
            this.selectcitycmb = new System.Windows.Forms.ComboBox();
            this.selecthotelcmb = new System.Windows.Forms.ComboBox();
            this.totalpersoncmb = new System.Windows.Forms.ComboBox();
            this.numberofdayscmb = new System.Windows.Forms.ComboBox();
            this.c_in_lbl = new System.Windows.Forms.Label();
            this.c_out_lbl = new System.Windows.Forms.Label();
            this.c_in_dtp = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // c_out_dtp
            // 
            this.c_out_dtp.Location = new System.Drawing.Point(164, 277);
            this.c_out_dtp.Margin = new System.Windows.Forms.Padding(4);
            this.c_out_dtp.Name = "c_out_dtp";
            this.c_out_dtp.Size = new System.Drawing.Size(212, 22);
            this.c_out_dtp.TabIndex = 68;
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(319, 381);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 34);
            this.delete.TabIndex = 92;
            this.delete.Text = "Delete";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // Load
            // 
            this.Load.Location = new System.Drawing.Point(565, 385);
            this.Load.Name = "Load";
            this.Load.Size = new System.Drawing.Size(75, 30);
            this.Load.TabIndex = 72;
            this.Load.Text = "Load";
            this.Load.UseVisualStyleBackColor = true;
            this.Load.Click += new System.EventHandler(this.Load_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(12, 404);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(75, 34);
            this.Back.TabIndex = 71;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(127, 381);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 34);
            this.Clear.TabIndex = 70;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Update
            // 
            this.Update.Location = new System.Drawing.Point(224, 381);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(75, 34);
            this.Update.TabIndex = 69;
            this.Update.Text = "Update";
            this.Update.UseVisualStyleBackColor = true;
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(272, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 29);
            this.label1.TabIndex = 45;
            this.label1.Text = "Update Hotel Details";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(417, 79);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(370, 299);
            this.dataGridView1.TabIndex = 46;
            // 
            // selectcitylbl
            // 
            this.selectcitylbl.AutoSize = true;
            this.selectcitylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectcitylbl.Location = new System.Drawing.Point(62, 102);
            this.selectcitylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectcitylbl.Name = "selectcitylbl";
            this.selectcitylbl.Size = new System.Drawing.Size(94, 18);
            this.selectcitylbl.TabIndex = 48;
            this.selectcitylbl.Text = "Select City:";
            // 
            // selecthotellbl
            // 
            this.selecthotellbl.AutoSize = true;
            this.selecthotellbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selecthotellbl.Location = new System.Drawing.Point(51, 129);
            this.selecthotellbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selecthotellbl.Name = "selecthotellbl";
            this.selecthotellbl.Size = new System.Drawing.Size(105, 18);
            this.selecthotellbl.TabIndex = 49;
            this.selecthotellbl.Text = "Select Hotel:";
            // 
            // totalpersonlbl
            // 
            this.totalpersonlbl.AutoSize = true;
            this.totalpersonlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalpersonlbl.Location = new System.Drawing.Point(46, 164);
            this.totalpersonlbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalpersonlbl.Name = "totalpersonlbl";
            this.totalpersonlbl.Size = new System.Drawing.Size(110, 18);
            this.totalpersonlbl.TabIndex = 50;
            this.totalpersonlbl.Text = "Total Person:";
            // 
            // numberofdayslbl
            // 
            this.numberofdayslbl.AutoSize = true;
            this.numberofdayslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberofdayslbl.Location = new System.Drawing.Point(18, 201);
            this.numberofdayslbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numberofdayslbl.Name = "numberofdayslbl";
            this.numberofdayslbl.Size = new System.Drawing.Size(138, 18);
            this.numberofdayslbl.TabIndex = 51;
            this.numberofdayslbl.Text = "Number Of Days:";
            // 
            // selectcitycmb
            // 
            this.selectcitycmb.FormattingEnabled = true;
            this.selectcitycmb.Items.AddRange(new object[] {
            "Choose City",
            "Dhaka",
            "Cox\'s Bazar",
            "Sylhet"});
            this.selectcitycmb.Location = new System.Drawing.Point(164, 96);
            this.selectcitycmb.Margin = new System.Windows.Forms.Padding(4);
            this.selectcitycmb.Name = "selectcitycmb";
            this.selectcitycmb.Size = new System.Drawing.Size(212, 24);
            this.selectcitycmb.TabIndex = 56;
            // 
            // selecthotelcmb
            // 
            this.selecthotelcmb.FormattingEnabled = true;
            this.selecthotelcmb.Items.AddRange(new object[] {
            "Choose Your Hotel Please",
            "Intercontinental",
            "Royal Tulip",
            "Grand Sultan"});
            this.selecthotelcmb.Location = new System.Drawing.Point(164, 128);
            this.selecthotelcmb.Margin = new System.Windows.Forms.Padding(4);
            this.selecthotelcmb.Name = "selecthotelcmb";
            this.selecthotelcmb.Size = new System.Drawing.Size(212, 24);
            this.selecthotelcmb.TabIndex = 57;
            // 
            // totalpersoncmb
            // 
            this.totalpersoncmb.FormattingEnabled = true;
            this.totalpersoncmb.Items.AddRange(new object[] {
            "Select How Many Person",
            "1",
            "2",
            "3",
            "4"});
            this.totalpersoncmb.Location = new System.Drawing.Point(164, 163);
            this.totalpersoncmb.Margin = new System.Windows.Forms.Padding(4);
            this.totalpersoncmb.Name = "totalpersoncmb";
            this.totalpersoncmb.Size = new System.Drawing.Size(212, 24);
            this.totalpersoncmb.TabIndex = 58;
            // 
            // numberofdayscmb
            // 
            this.numberofdayscmb.FormattingEnabled = true;
            this.numberofdayscmb.Items.AddRange(new object[] {
            "Choose Your Length Of Stay",
            "1",
            "2",
            "3",
            "4"});
            this.numberofdayscmb.Location = new System.Drawing.Point(164, 201);
            this.numberofdayscmb.Margin = new System.Windows.Forms.Padding(4);
            this.numberofdayscmb.Name = "numberofdayscmb";
            this.numberofdayscmb.Size = new System.Drawing.Size(212, 24);
            this.numberofdayscmb.TabIndex = 59;
            // 
            // c_in_lbl
            // 
            this.c_in_lbl.AutoSize = true;
            this.c_in_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c_in_lbl.Location = new System.Drawing.Point(76, 238);
            this.c_in_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_in_lbl.Name = "c_in_lbl";
            this.c_in_lbl.Size = new System.Drawing.Size(80, 18);
            this.c_in_lbl.TabIndex = 65;
            this.c_in_lbl.Text = "Check-In:";
            // 
            // c_out_lbl
            // 
            this.c_out_lbl.AutoSize = true;
            this.c_out_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c_out_lbl.Location = new System.Drawing.Point(62, 277);
            this.c_out_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_out_lbl.Name = "c_out_lbl";
            this.c_out_lbl.Size = new System.Drawing.Size(94, 18);
            this.c_out_lbl.TabIndex = 66;
            this.c_out_lbl.Text = "Check-Out:";
            // 
            // c_in_dtp
            // 
            this.c_in_dtp.Location = new System.Drawing.Point(164, 238);
            this.c_in_dtp.Margin = new System.Windows.Forms.Padding(4);
            this.c_in_dtp.Name = "c_in_dtp";
            this.c_in_dtp.Size = new System.Drawing.Size(212, 22);
            this.c_in_dtp.TabIndex = 67;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 322);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 18);
            this.label2.TabIndex = 93;
            this.label2.Text = "Hotel Room Price:";
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(164, 322);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(212, 22);
            this.textBoxPrice.TabIndex = 94;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LetsTravel.Properties.Resources.IMG_9373;
            this.pictureBox2.Location = new System.Drawing.Point(11, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(76, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 95;
            this.pictureBox2.TabStop = false;
            // 
            // UpdateHotelByAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.Load);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.c_out_dtp);
            this.Controls.Add(this.c_in_dtp);
            this.Controls.Add(this.c_out_lbl);
            this.Controls.Add(this.c_in_lbl);
            this.Controls.Add(this.numberofdayscmb);
            this.Controls.Add(this.totalpersoncmb);
            this.Controls.Add(this.selecthotelcmb);
            this.Controls.Add(this.selectcitycmb);
            this.Controls.Add(this.numberofdayslbl);
            this.Controls.Add(this.totalpersonlbl);
            this.Controls.Add(this.selecthotellbl);
            this.Controls.Add(this.selectcitylbl);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UpdateHotelByAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Hotel By Admin";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker c_out_dtp;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button Load;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label selectcitylbl;
        private System.Windows.Forms.Label selecthotellbl;
        private System.Windows.Forms.Label totalpersonlbl;
        private System.Windows.Forms.Label numberofdayslbl;
        private System.Windows.Forms.ComboBox selectcitycmb;
        private System.Windows.Forms.ComboBox selecthotelcmb;
        private System.Windows.Forms.ComboBox totalpersoncmb;
        private System.Windows.Forms.ComboBox numberofdayscmb;
        private System.Windows.Forms.Label c_in_lbl;
        private System.Windows.Forms.Label c_out_lbl;
        private System.Windows.Forms.DateTimePicker c_in_dtp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}