﻿namespace LetsTravel
{
    partial class ResortUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResortUser));
            this.Payment = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Search = new System.Windows.Forms.Button();
            this.c_out_dtp = new System.Windows.Forms.DateTimePicker();
            this.c_in_dtp = new System.Windows.Forms.DateTimePicker();
            this.c_out_lbl = new System.Windows.Forms.Label();
            this.c_in_lbl = new System.Windows.Forms.Label();
            this.numberofdayscmb = new System.Windows.Forms.ComboBox();
            this.totalpersoncmb = new System.Windows.Forms.ComboBox();
            this.selectresortcmb = new System.Windows.Forms.ComboBox();
            this.selectcitycmb = new System.Windows.Forms.ComboBox();
            this.numberofdayslbl = new System.Windows.Forms.Label();
            this.totalpersonlbl = new System.Windows.Forms.Label();
            this.selecthotellbl = new System.Windows.Forms.Label();
            this.selectcitylbl = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Payment
            // 
            this.Payment.Location = new System.Drawing.Point(547, 306);
            this.Payment.Name = "Payment";
            this.Payment.Size = new System.Drawing.Size(75, 35);
            this.Payment.TabIndex = 109;
            this.Payment.Text = "Payment";
            this.Payment.UseVisualStyleBackColor = true;
            this.Payment.Click += new System.EventHandler(this.Payment_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(16, 397);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(75, 34);
            this.Back.TabIndex = 108;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(156, 325);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 34);
            this.Clear.TabIndex = 107;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(272, 325);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(75, 34);
            this.Search.TabIndex = 106;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // c_out_dtp
            // 
            this.c_out_dtp.Location = new System.Drawing.Point(156, 270);
            this.c_out_dtp.Margin = new System.Windows.Forms.Padding(4);
            this.c_out_dtp.Name = "c_out_dtp";
            this.c_out_dtp.Size = new System.Drawing.Size(212, 22);
            this.c_out_dtp.TabIndex = 105;
            // 
            // c_in_dtp
            // 
            this.c_in_dtp.Location = new System.Drawing.Point(156, 231);
            this.c_in_dtp.Margin = new System.Windows.Forms.Padding(4);
            this.c_in_dtp.Name = "c_in_dtp";
            this.c_in_dtp.Size = new System.Drawing.Size(212, 22);
            this.c_in_dtp.TabIndex = 104;
            // 
            // c_out_lbl
            // 
            this.c_out_lbl.AutoSize = true;
            this.c_out_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c_out_lbl.Location = new System.Drawing.Point(54, 274);
            this.c_out_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_out_lbl.Name = "c_out_lbl";
            this.c_out_lbl.Size = new System.Drawing.Size(94, 18);
            this.c_out_lbl.TabIndex = 103;
            this.c_out_lbl.Text = "Check-Out:";
            // 
            // c_in_lbl
            // 
            this.c_in_lbl.AutoSize = true;
            this.c_in_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c_in_lbl.Location = new System.Drawing.Point(68, 231);
            this.c_in_lbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c_in_lbl.Name = "c_in_lbl";
            this.c_in_lbl.Size = new System.Drawing.Size(80, 18);
            this.c_in_lbl.TabIndex = 102;
            this.c_in_lbl.Text = "Check-In:";
            // 
            // numberofdayscmb
            // 
            this.numberofdayscmb.FormattingEnabled = true;
            this.numberofdayscmb.Items.AddRange(new object[] {
            "Choose Your Length Of Stay",
            "1",
            "2",
            "3",
            "4"});
            this.numberofdayscmb.Location = new System.Drawing.Point(156, 194);
            this.numberofdayscmb.Margin = new System.Windows.Forms.Padding(4);
            this.numberofdayscmb.Name = "numberofdayscmb";
            this.numberofdayscmb.Size = new System.Drawing.Size(212, 24);
            this.numberofdayscmb.TabIndex = 101;
            // 
            // totalpersoncmb
            // 
            this.totalpersoncmb.FormattingEnabled = true;
            this.totalpersoncmb.Items.AddRange(new object[] {
            "Select How Many Person",
            "1",
            "2",
            "3",
            "4"});
            this.totalpersoncmb.Location = new System.Drawing.Point(156, 156);
            this.totalpersoncmb.Margin = new System.Windows.Forms.Padding(4);
            this.totalpersoncmb.Name = "totalpersoncmb";
            this.totalpersoncmb.Size = new System.Drawing.Size(212, 24);
            this.totalpersoncmb.TabIndex = 100;
            // 
            // selectresortcmb
            // 
            this.selectresortcmb.FormattingEnabled = true;
            this.selectresortcmb.Items.AddRange(new object[] {
            "Choose Your Resort Please",
            "Intercontinental",
            "Grand Sylhet ",
            "Mermaid Beach Resort"});
            this.selectresortcmb.Location = new System.Drawing.Point(156, 126);
            this.selectresortcmb.Margin = new System.Windows.Forms.Padding(4);
            this.selectresortcmb.Name = "selectresortcmb";
            this.selectresortcmb.Size = new System.Drawing.Size(212, 24);
            this.selectresortcmb.TabIndex = 99;
            // 
            // selectcitycmb
            // 
            this.selectcitycmb.FormattingEnabled = true;
            this.selectcitycmb.Items.AddRange(new object[] {
            "Choose City",
            "Dhaka",
            "Cox\'s Bazar",
            "Sylhet"});
            this.selectcitycmb.Location = new System.Drawing.Point(156, 94);
            this.selectcitycmb.Margin = new System.Windows.Forms.Padding(4);
            this.selectcitycmb.Name = "selectcitycmb";
            this.selectcitycmb.Size = new System.Drawing.Size(212, 24);
            this.selectcitycmb.TabIndex = 98;
            // 
            // numberofdayslbl
            // 
            this.numberofdayslbl.AutoSize = true;
            this.numberofdayslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberofdayslbl.Location = new System.Drawing.Point(10, 194);
            this.numberofdayslbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numberofdayslbl.Name = "numberofdayslbl";
            this.numberofdayslbl.Size = new System.Drawing.Size(138, 18);
            this.numberofdayslbl.TabIndex = 97;
            this.numberofdayslbl.Text = "Number Of Days:";
            // 
            // totalpersonlbl
            // 
            this.totalpersonlbl.AutoSize = true;
            this.totalpersonlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalpersonlbl.Location = new System.Drawing.Point(38, 156);
            this.totalpersonlbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalpersonlbl.Name = "totalpersonlbl";
            this.totalpersonlbl.Size = new System.Drawing.Size(110, 18);
            this.totalpersonlbl.TabIndex = 96;
            this.totalpersonlbl.Text = "Total Person:";
            // 
            // selecthotellbl
            // 
            this.selecthotellbl.AutoSize = true;
            this.selecthotellbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selecthotellbl.Location = new System.Drawing.Point(32, 127);
            this.selecthotellbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selecthotellbl.Name = "selecthotellbl";
            this.selecthotellbl.Size = new System.Drawing.Size(116, 18);
            this.selecthotellbl.TabIndex = 95;
            this.selecthotellbl.Text = "Select Resort:";
            // 
            // selectcitylbl
            // 
            this.selectcitylbl.AutoSize = true;
            this.selectcitylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectcitylbl.Location = new System.Drawing.Point(54, 95);
            this.selectcitylbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectcitylbl.Name = "selectcitylbl";
            this.selectcitylbl.Size = new System.Drawing.Size(94, 18);
            this.selectcitylbl.TabIndex = 94;
            this.selectcitylbl.Text = "Select City:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(387, 126);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(404, 142);
            this.dataGridView1.TabIndex = 93;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(300, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 29);
            this.label1.TabIndex = 92;
            this.label1.Text = "Booking Resort";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LetsTravel.Properties.Resources.IMG_9373;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(79, 65);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 110;
            this.pictureBox2.TabStop = false;
            // 
            // ResortUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Payment);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.c_out_dtp);
            this.Controls.Add(this.c_in_dtp);
            this.Controls.Add(this.c_out_lbl);
            this.Controls.Add(this.c_in_lbl);
            this.Controls.Add(this.numberofdayscmb);
            this.Controls.Add(this.totalpersoncmb);
            this.Controls.Add(this.selectresortcmb);
            this.Controls.Add(this.selectcitycmb);
            this.Controls.Add(this.numberofdayslbl);
            this.Controls.Add(this.totalpersonlbl);
            this.Controls.Add(this.selecthotellbl);
            this.Controls.Add(this.selectcitylbl);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ResortUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resort User";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Payment;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.DateTimePicker c_out_dtp;
        private System.Windows.Forms.DateTimePicker c_in_dtp;
        private System.Windows.Forms.Label c_out_lbl;
        private System.Windows.Forms.Label c_in_lbl;
        private System.Windows.Forms.ComboBox numberofdayscmb;
        private System.Windows.Forms.ComboBox totalpersoncmb;
        private System.Windows.Forms.ComboBox selectresortcmb;
        private System.Windows.Forms.ComboBox selectcitycmb;
        private System.Windows.Forms.Label numberofdayslbl;
        private System.Windows.Forms.Label totalpersonlbl;
        private System.Windows.Forms.Label selecthotellbl;
        private System.Windows.Forms.Label selectcitylbl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}