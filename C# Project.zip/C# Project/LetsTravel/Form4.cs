﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LetsTravel
{
    public partial class UserDashboard : Form
    {
        public UserDashboard()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login lg = new Login();
            lg.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation",
                                         MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If the user clicks "Yes", close the application
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Payment_Click(object sender, EventArgs e)
        {
            this.Hide();
            Payment a = new Payment();
            a.Show();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login l = new Login();
            l.Show();
        }

        private void UserPersonalInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserInfo u = new UserInfo();
            u.Show();
        }

        private void UpdateUserInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateUserInfo u = new UpdateUserInfo();
            u.Show();
        }

        private void UserHistory_Click(object sender, EventArgs e)
        {

        }

        private void Hotel_Click(object sender, EventArgs e)
        {
            this.Hide();
            HotelUser h = new HotelUser();
            h.Show();
        }

        private void Ticket_Click(object sender, EventArgs e)
        {
            this.Hide();
            FromTicketuser t = new FromTicketuser();
            t.Show();
        }

        private void Resort_Click(object sender, EventArgs e)
        {
            this.Hide();
            ResortUser r = new ResortUser();
            r.Show();
        }
    }
}
