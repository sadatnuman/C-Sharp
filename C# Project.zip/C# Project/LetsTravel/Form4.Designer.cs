﻿namespace LetsTravel
{
    partial class UserDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserDashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Resort = new System.Windows.Forms.Button();
            this.Restaurant = new System.Windows.Forms.Button();
            this.Hotel = new System.Windows.Forms.Button();
            this.Ticket = new System.Windows.Forms.Button();
            this.Package = new System.Windows.Forms.Button();
            this.UserPersonalInfo = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LogOut = new System.Windows.Forms.Button();
            this.UpdateUserInfo = new System.Windows.Forms.Button();
            this.UserHistory = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.Resort);
            this.panel1.Controls.Add(this.Restaurant);
            this.panel1.Controls.Add(this.Hotel);
            this.panel1.Controls.Add(this.Ticket);
            this.panel1.Controls.Add(this.Package);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 100);
            this.panel1.TabIndex = 0;
            // 
            // Resort
            // 
            this.Resort.Location = new System.Drawing.Point(541, 26);
            this.Resort.Name = "Resort";
            this.Resort.Size = new System.Drawing.Size(111, 40);
            this.Resort.TabIndex = 4;
            this.Resort.Text = "Resort";
            this.Resort.UseVisualStyleBackColor = true;
            this.Resort.Click += new System.EventHandler(this.Resort_Click);
            // 
            // Restaurant
            // 
            this.Restaurant.Location = new System.Drawing.Point(658, 26);
            this.Restaurant.Name = "Restaurant";
            this.Restaurant.Size = new System.Drawing.Size(130, 40);
            this.Restaurant.TabIndex = 3;
            this.Restaurant.Text = "Restaurant";
            this.Restaurant.UseVisualStyleBackColor = true;
            this.Restaurant.Click += new System.EventHandler(this.button4_Click);
            // 
            // Hotel
            // 
            this.Hotel.Location = new System.Drawing.Point(430, 26);
            this.Hotel.Name = "Hotel";
            this.Hotel.Size = new System.Drawing.Size(105, 40);
            this.Hotel.TabIndex = 2;
            this.Hotel.Text = "Hotel";
            this.Hotel.UseVisualStyleBackColor = true;
            this.Hotel.Click += new System.EventHandler(this.Hotel_Click);
            // 
            // Ticket
            // 
            this.Ticket.Location = new System.Drawing.Point(328, 26);
            this.Ticket.Name = "Ticket";
            this.Ticket.Size = new System.Drawing.Size(96, 40);
            this.Ticket.TabIndex = 1;
            this.Ticket.Text = "Ticket";
            this.Ticket.UseVisualStyleBackColor = true;
            this.Ticket.Click += new System.EventHandler(this.Ticket_Click);
            // 
            // Package
            // 
            this.Package.Location = new System.Drawing.Point(213, 26);
            this.Package.Name = "Package";
            this.Package.Size = new System.Drawing.Size(109, 40);
            this.Package.TabIndex = 0;
            this.Package.Text = "Package";
            this.Package.UseVisualStyleBackColor = true;
            // 
            // UserPersonalInfo
            // 
            this.UserPersonalInfo.Location = new System.Drawing.Point(12, 36);
            this.UserPersonalInfo.Name = "UserPersonalInfo";
            this.UserPersonalInfo.Size = new System.Drawing.Size(148, 43);
            this.UserPersonalInfo.TabIndex = 2;
            this.UserPersonalInfo.Text = "User Personal Info";
            this.UserPersonalInfo.UseVisualStyleBackColor = true;
            this.UserPersonalInfo.Click += new System.EventHandler(this.UserPersonalInfo_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.LogOut);
            this.panel2.Controls.Add(this.UpdateUserInfo);
            this.panel2.Controls.Add(this.UserHistory);
            this.panel2.Controls.Add(this.UserPersonalInfo);
            this.panel2.Location = new System.Drawing.Point(0, 98);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(191, 353);
            this.panel2.TabIndex = 1;
            // 
            // LogOut
            // 
            this.LogOut.Location = new System.Drawing.Point(12, 285);
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(148, 43);
            this.LogOut.TabIndex = 2;
            this.LogOut.Text = "Log Out";
            this.LogOut.UseVisualStyleBackColor = true;
            this.LogOut.Click += new System.EventHandler(this.button1_Click);
            // 
            // UpdateUserInfo
            // 
            this.UpdateUserInfo.Location = new System.Drawing.Point(12, 201);
            this.UpdateUserInfo.Name = "UpdateUserInfo";
            this.UpdateUserInfo.Size = new System.Drawing.Size(148, 43);
            this.UpdateUserInfo.TabIndex = 2;
            this.UpdateUserInfo.Text = "Update User Info";
            this.UpdateUserInfo.UseVisualStyleBackColor = true;
            this.UpdateUserInfo.Click += new System.EventHandler(this.UpdateUserInfo_Click);
            // 
            // UserHistory
            // 
            this.UserHistory.Location = new System.Drawing.Point(12, 120);
            this.UserHistory.Name = "UserHistory";
            this.UserHistory.Size = new System.Drawing.Size(148, 37);
            this.UserHistory.TabIndex = 2;
            this.UserHistory.Text = "User History";
            this.UserHistory.UseVisualStyleBackColor = true;
            this.UserHistory.Click += new System.EventHandler(this.UserHistory_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(233, 395);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(75, 43);
            this.Back.TabIndex = 2;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(658, 395);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(92, 43);
            this.Exit.TabIndex = 4;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LetsTravel.Properties.Resources.Image;
            this.pictureBox1.Location = new System.Drawing.Point(249, 106);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(468, 283);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LetsTravel.Properties.Resources.IMG_9373;
            this.pictureBox2.Location = new System.Drawing.Point(21, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(112, 80);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // UserDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UserDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserDashboard";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button UserPersonalInfo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button UpdateUserInfo;
        private System.Windows.Forms.Button UserHistory;
        private System.Windows.Forms.Button LogOut;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Restaurant;
        private System.Windows.Forms.Button Hotel;
        private System.Windows.Forms.Button Ticket;
        private System.Windows.Forms.Button Package;
        private System.Windows.Forms.Button Resort;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}