﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LetsTravel
{
    public partial class Login : Form
    {

        DBCoonect dbcon = new DBCoonect();
       

        public Login()
        {
            InitializeComponent();
 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (rolecombox.SelectedIndex > 0)
                {
                    if(usernametxt.Text == String.Empty)
                    {
                        MessageBox.Show("Please enter User Name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        usernametxt.Focus();

                        return;
                    }
                    if(passwordtxt.Text == String.Empty)
                    {
                        MessageBox.Show("Please enter Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        passwordtxt.Focus();
                        return;
                    }
                    if(rolecombox.SelectedIndex > 0 && usernametxt.Text != string.Empty && passwordtxt.Text != string.Empty)
                    {
                        if(rolecombox.Text == "Admin")
                        {
                            SqlCommand cmd = new SqlCommand("select * from Admin where Username = @Username and Password = @Password", dbcon.GetCon());
                            cmd.Parameters.AddWithValue("@Username", usernametxt.Text);
                            cmd.Parameters.AddWithValue("@Password", passwordtxt.Text);
                            dbcon.OpenCon();
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            if(dt.Rows.Count > 0)
                            {
                                MessageBox.Show("Login Success Welcome to Let's Travel.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Hide();
                                AdminDashboard ad = new AdminDashboard();
                                ad.Show();
                                dbcon.CloseCon();
                            }
                            else
                            {
                                MessageBox.Show("Invalid login. Please check user name and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                        }
                        if(rolecombox.Text == "User")
                        {
                            SqlCommand cmd = new SqlCommand("select * from Registration where Username = @Username and Password = @Password", dbcon.GetCon());
                            cmd.Parameters.AddWithValue("@Username", usernametxt.Text);
                            cmd.Parameters.AddWithValue("@Password", passwordtxt.Text);
                            dbcon.OpenCon();
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            if (dt.Rows.Count > 0)
                            {
                                MessageBox.Show("Login Success Welcome to Let's Travel.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Hide();
                                UserDashboard ur = new UserDashboard();
                                ur.Show();
                                dbcon.CloseCon();
                            }
                            else
                            {
                                MessageBox.Show("Invalid login. Please check user name and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select any role.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    rolecombox.SelectedIndex = 0;
                    usernametxt.Clear();
                    passwordtxt.Clear();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void registerbutton_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            Registration r = new Registration();
            r.Show();
   
        }

        private void Login_Load(object sender, EventArgs e)
        {
            rolecombox.SelectedIndex = 0;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation",
                                         MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If the user clicks "Yes", close the application
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
