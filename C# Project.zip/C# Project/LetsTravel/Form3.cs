﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LetsTravel
{
    public partial class AdminDashboard : Form
    {
        DBCoonect dbcon = new DBCoonect();
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            FromTicketadmin f = new FromTicketadmin();
            f.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void UpdateHotel_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateHotelByAdmin u = new UpdateHotelByAdmin();
            u.Show();

        }

        private void UpdateAdminInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateAdminInfo u = new UpdateAdminInfo();
            u.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dbcon.OpenCon();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Admin", dbcon.GetCon());
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dataGridView1.DataSource = dt;
        }

        private void Load_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Admin", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login lg = new Login();
            lg.Show();
        }

        private void AddUser_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddUserByAdmin addUserByAdmin = new AddUserByAdmin();
            addUserByAdmin.Show();
            
        }

        private void UpdateUserInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateUserByAdmin ur = new UpdateUserByAdmin();
            ur.Show();
        }

        private void PymentDetails_Click(object sender, EventArgs e)
        {

        }

        private void UpdateResort_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateResortByAdmin u = new UpdateResortByAdmin();
            u.Show();
        }

        private void AdminDashboard_Load_1(object sender, EventArgs e)
        {

        }

        private void DeleteUser_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteUserByAdmin d = new DeleteUserByAdmin();
            d.Show();
        }

        private void AddAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddAdmin a = new AddAdmin();
            a.Show();
        }

        private void DeleteAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteAdmin d = new DeleteAdmin();
            d.Show();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation",
                                         MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If the user clicks "Yes", close the application
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login l = new Login();
            l.Show();
        }

        private void AdminDashboard_Load_2(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
