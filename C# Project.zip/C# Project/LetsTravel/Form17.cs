﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LetsTravel
{
    public partial class FromTicketuser : Form
    {
        public FromTicketuser()
        {
            InitializeComponent();
            comboBoxTransport.SelectedIndex = 0;
            comboBoxFrom.SelectedIndex = 0;
            comboBoxTo.SelectedIndex = 0;
            dateTimePicker1.Value = DateTime.Now;
            comboBoxTime.SelectedIndex = 0;
            comboBoxSeat.SelectedIndex = 0;
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserDashboard u = new UserDashboard();
            u.Show();
        }

        private void buttonPayment_Click(object sender, EventArgs e)
        {
            this.Hide();
            Payment p = new Payment();
            p.Show();
        }

        private void buttonSearchtrain_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBoxTransport.SelectedIndex > 0)
                {
                    if (comboBoxFrom.SelectedIndex > 0 && comboBoxTo.SelectedIndex > 0)
                    {
                        if (comboBoxFrom.SelectedIndex == comboBoxTo.SelectedIndex)
                        {
                            MessageBox.Show("Please select diffrent places ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            comboBoxFrom.SelectedIndex = 0;
                            comboBoxTo.SelectedIndex = 0;
                        }
                        if (comboBoxTime.SelectedIndex > 0)
                        {

                            if (comboBoxSeat.SelectedIndex > 0)
                            {
                                using (SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-HMQ84RV\SQLEXPRESS;Initial Catalog=LetsTravel;Integrated Security=True"))
                                {
                                    cn.Open();

                                    // Parameterized Query (Prevents SQL Injection)
                                    string query = "SELECT * FROM Ticket WHERE Transport = @Transport AND Frm = @From AND Too = @To AND Date = @Date AND Time = @Time AND Seat = @Seat";

                                    using (SqlCommand cmd = new SqlCommand(query, cn))
                                    {
                                        // Adding parameters to prevent SQL injection
                                        cmd.Parameters.AddWithValue("@Transport", comboBoxTransport.Text);
                                        cmd.Parameters.AddWithValue("@From", comboBoxFrom.Text);
                                        cmd.Parameters.AddWithValue("@To", comboBoxTo.Text);
                                        cmd.Parameters.AddWithValue("@Date", dateTimePicker1.Value.Date); // Ensures only Date part
                                        cmd.Parameters.AddWithValue("@Time", comboBoxTime.Text);
                                        cmd.Parameters.AddWithValue("@Seat", comboBoxSeat.Text);

                                        // Using SqlDataAdapter to fill the DataTable
                                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                                        DataTable dt = new DataTable();
                                        sda.Fill(dt);

                                        // Binding the result to DataGridView
                                        dataGridView1.DataSource = dt;
                                    }
                                }

                            }
                            else
                            {
                                MessageBox.Show("Please select any seat", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select any time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select From place and To place", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please select any transport", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FromTicketuser_Load(object sender, EventArgs e)
        {

        }
    }
}
